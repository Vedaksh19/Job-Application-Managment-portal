package model;

public class Employer extends User {
    public Employer(String username, String password) {
        super(username, password, "Employer");
    }
}